package com.example.pf

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
